# Got Tell It on the Mountain || James Baldwin

A Pen created on CodePen.io. Original URL: [https://codepen.io/Faezah-Mahtar/pen/xxvyXee](https://codepen.io/Faezah-Mahtar/pen/xxvyXee).

My Favorite Quotes from Got Tell It on the Mountain || James Baldwin		
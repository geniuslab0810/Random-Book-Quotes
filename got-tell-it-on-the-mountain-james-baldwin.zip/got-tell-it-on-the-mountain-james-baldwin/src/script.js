document.getElementsByTagName("h1")[0].style.fontSize = "3vw";

document.getElementsByTagName("h2")[0].style.fontSize = "3vw";

